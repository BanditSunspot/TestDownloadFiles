import ctypes
import urllib.request

from kivymd.uix.boxlayout import MDBoxLayout
from urllib.request import urlopen
from urllib.parse import urljoin
from io import BytesIO
import zipfile

class Updater(MDBoxLayout):
    def __init__(self, **kwargs):
        super(Updater, self).__init__(**kwargs)

    def CheckVersion(self):
        update = False
        self.versionFile = "Version.txt"
        self.serverLocation = "https://raw.githubusercontent.com/BanditSunspot/TestDownloadFiles/TestZip/"
        desktopFile = open("./"+self.versionFile, "r")
        desktopVersion = desktopFile.read()
        serverVersionFile = urllib.request.urlopen(self.serverLocation+self.versionFile)
        self.serverVersion = ""
        for line in serverVersionFile:
            self.serverVersion = line.decode("utf-8")
        if(int(desktopVersion.replace('.','')) < int(self.serverVersion.replace('.',''))):
            self.Mbox('Update detected', 'Current version: '+desktopVersion+'\nNew version: '+self.serverVersion, 0)
            update = True
        desktopFile.close()
        serverVersionFile.close()
        return update


    def Mbox(self, title, text, style):
        return ctypes.windll.user32.MessageBoxW(0, text, title, style)

    def DoUpdate(self):
        SaveDirectory = "./"
        DownloadZip = urlopen(urljoin(self.serverLocation, self.serverVersion+".zip"))
        with zipfile.ZipFile(BytesIO(DownloadZip.read()), 'r') as zip_ref:
            zip_ref.extractall(SaveDirectory)
        print("Update Done")
import ctypes  # An included library with Python install.
import urllib.request

from kivymd.uix.boxlayout import MDBoxLayout
from urllib.request import urlretrieve
from urllib.request import urlopen
import os

class Updater(MDBoxLayout):
    def __init__(self, **kwargs):
        super(Updater, self).__init__(**kwargs)

    def CheckVersion(self):
        update = False
        self.serverVersionFile = "https://raw.githubusercontent.com/BanditSunspot/TestDownloadFiles/tree/testZip/Version.txt"
        self.versionFile = "./Version.txt"
        desktopFile = open(self.versionFile, "r")
        desktopVersion = desktopFile.read()
        serverVersionFile = urllib.request.urlopen(self.serverVersionFile)
        serverVersion = ""
        for line in serverVersionFile:
            serverVersion = line.decode("utf-8")
        if(int(desktopVersion.replace('.','')) < int(serverVersion.replace('.',''))):
            self.Mbox('Update detected', 'Current version: '+desktopVersion+'\nNew version: '+serverVersion, 0)
            update = True
        desktopFile.close()
        serverVersionFile.close()
        return update


    def Mbox(self, title, text, style):
        return ctypes.windll.user32.MessageBoxW(0, text, title, style)

    def DoUpdate(self):
        print("Update in progress...")
from kivymd.app import MDApp
from kivy.core.window import Window

from controller.LauncherController import LauncherController
from kivy.lang import Builder
import os, sys
from updater.Updater import Updater

Builder.load_file("./KvFiles/KvFunctions.kv")


class AfoLauncherApp(MDApp):
    def build(self):
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Gray"
        self.theme_cls.material_style = "M3"
        Window.size = 1000, 720
        controller = LauncherController()
        updater = Updater()
        if(updater.CheckVersion()):
            updater.DoUpdate()
            self.Reboot()
        return controller.client_windows

    def Reboot(self):
        print("argv was", sys.argv)
        print("sys.executable was", sys.executable)
        print("restart now")

        AfoLauncherApp().run()
        exit()


if __name__ == "__main__":
    AfoLauncherApp().run()

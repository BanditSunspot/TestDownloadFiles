from kivymd.app import MDApp
from kivy.core.window import Window

from controller.LauncherController import LauncherController
from kivy.lang import Builder
import os
import subprocess
import urllib.request
import ctypes
from updater.Updater import Updater

Builder.load_file("./KvFiles/KvFunctions.kv")


class AfoLauncherApp(MDApp):
    def build(self):
        self.Updates()
        self.theme_cls.theme_style = "Dark"
        self.theme_cls.primary_palette = "Gray"
        self.theme_cls.material_style = "M3"
        Window.size = 1000, 720
        controller = LauncherController()

        # Run the target script
        return controller.client_windows

    def Updates(self):
        updaterLoc = "./updater/Updater.py"
        # Construct the relative path to the target script
        res = 1
        if(self.CheckVersion()):
            script_path = os.path.join(os.path.dirname(__file__), updaterLoc)
            res = subprocess.run(['python', script_path, str(os.getpid())], start_new_session=True)
        return res

    def CheckVersion(self):
        update = False
        self.versionFile = "Version.txt"
        self.serverLocation = "https://raw.githubusercontent.com/BanditSunspot/TestDownloadFiles/TestZip/"
        desktopFile = open("./"+self.versionFile, "r")
        desktopVersion = desktopFile.read()
        serverVersionFile = urllib.request.urlopen(self.serverLocation+self.versionFile)
        self.serverVersion = ""
        for line in serverVersionFile:
            self.serverVersion = line.decode("utf-8")
        if(int(desktopVersion.replace('.','')) < int(self.serverVersion.replace('.',''))):
            self.Mbox('Update detected', 'Current version: '+desktopVersion+'\nNew version: '+self.serverVersion, 0)
            update = True
        desktopFile.close()
        serverVersionFile.close()
        return update

    def Mbox(self, title, text, style):
        return ctypes.windll.user32.MessageBoxW(0, text, title, style)

if __name__ == "__main__":
    AfoLauncherApp().run()
